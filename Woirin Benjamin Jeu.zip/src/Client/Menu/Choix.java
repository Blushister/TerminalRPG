package Client.Menu;

import Client.Joueur.Ami.Heros;
import Client.Objets.Arme.Arme;

import java.util.Scanner;

public class Choix {

    // constructeur

    public Choix() {

    }

    // methods

    public void choixMenuBoutique() {
        Scanner sc = new Scanner(System.in);
        int choix = sc.nextInt();
        switch (choix) {
            case 1:
                System.out.println("Acheter");
                break;
            case 2:
                System.out.println("Vendre");
                break;
            case 3:
                System.out.println("Quitter");
                break;
            default:
                System.out.println("Choix invalide");
                break;
        }
    }

    public Heros choixCreationPersonnage() {
        System.out.println("1 : Créer un personnage");
        System.out.println("2 : Quitter");
        Scanner sc = new Scanner(System.in);
        int choix = sc.nextInt();
        switch (choix) {
            case 1:
                System.out.println("Création d'un personnage");

                System.out.print("Choisissez votre nom : ");
                String nom = sc.next();

                Arme arme = new Arme("Epee", 10, 10, 10, 10, 10, 10);
                Heros heros = new Heros(nom, 100, 100, 10, 10, 1,1,1,1, arme);

                return heros;
            case 2:
                System.out.println("Quitter");
                break;
            default:
                System.out.println("Choix invalide");
                break;
        }

        if (choix == 2) {
            System.out.println("Quitter");

        }
        return null;
    }
}
