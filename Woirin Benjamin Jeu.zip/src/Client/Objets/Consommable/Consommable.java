package Client.Objets.Consommable;

import Client.Objets.Objects;


public class Consommable extends Objects {
    public int hp;
    public int mp;
    public int endurance;
    public int force;
    public int intelligence;
    public int agilite;
    public Object potionVie;


    public Consommable(String nom, int souls, int poids, int hp, int mp, int endurance, int force, int intelligence, int agilite) {
        super("Consommable", nom, poids, 0, 1, souls);
        this.hp = hp;
        this.mp = mp;
        this.endurance = endurance;
        this.force = force;
        this.intelligence = intelligence;
        this.agilite = agilite;
    }
}

