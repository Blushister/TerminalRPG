import Client.Joueur.Ami.Heros;
import Client.Joueur.Enemi.Vilain;
import Client.Maps.Maps;
import Client.Menu.Affichage.Affichage;
import Client.Menu.Choix;
import Client.Menu.Menu;
import Client.Network.Manager;
import Client.Objets.Arme.Arme;
import Client.Objets.Instancte;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        boolean debug = true;
        Heros heros;
        Arme arme = new Arme("Epee", 10, 10, 10, 1);
        Vilain vilain = new Vilain("Vilain", 100, 10, 10);
        Menu menu = new Menu("Start");
        Scanner sc = new Scanner(System.in);
        Choix choix = new Choix();
        Instancte instance = new Instancte();
        Affichage affichage = new Affichage();
        Maps maps = new Maps();
        if (debug) {
            heros = new Heros("Heros", 100, 100, 10, 1, 0,10,1,1, arme);
        } else {
            heros = choix.choixCreationPersonnage();
        }
        instance.InventaireStart(heros.inventory);
        maps.setHerosPosition(heros,15, 1);
        instance.Save(heros, arme);
        while (true) {
            if (heros.getVillage()) {
                menu.afficherMenuVillage();
                int choixMenu = sc.nextInt();
                switch (choixMenu) {
                    case 1:
                        heros.boutique();
                        break;
                    case 2:
                        instance.AfficherInventaire(heros, heros.inventory, menu);
                        break;
                    case 3:
                        affichage.afficherStats(heros);
                        break;
                    case 4:
                        System.out.println("Vous avez choisi de vous deplacer");
                        menu.MenuDeplacement();
                        int choixDeplacement = sc.nextInt();
                        switch (choixDeplacement) {
                            case 1:
                                maps.allerGauche(heros, instance, vilain);
                                break;
                            case 2:
                                maps.allerDroite(heros, instance, vilain);
                                break;
                            case 3:
                                maps.allerHaut(heros, instance, vilain);
                                break;
                            case 4:
                                maps.allerBas(heros, instance, vilain);
                                break;
                            case 5:
                                System.out.println("Vous avez choisi de quitter");
                                break;
                    }
                    break;
                    case 5:
                        System.out.println("Vous avez choisi de quitter");
                        break;
                }
            } else {
                menu.afficherMenu();
                int choixMenu = sc.nextInt();
                switch (choixMenu) {
                    case 1 :
                        instance.InstanceCombat(heros, vilain);
                        break;
                    case 2 :
                        System.out.println("Vous avez choisi de vous deplacer");
                        menu.MenuDeplacement();
                        int choixDeplacement = sc.nextInt();
                        switch (choixDeplacement) {
                            case 1:
                                maps.allerGauche(heros, instance, vilain);
                                maps.afficherMap();
                                break;
                            case 2 :
                                maps.allerDroite(heros, instance, vilain);
                                maps.afficherMap();
                                break;
                            case 3 :
                                maps.allerHaut(heros, instance, vilain);
                                maps.afficherMap();
                                break;
                            case 4 :
                                maps.allerBas(heros, instance, vilain);
                                maps.afficherMap();
                                break;
                            case 5 :
                                System.out.println("Vous avez choisi de quitter");
                                break;
                    }
                    break;
                    case 3 :
                        System.out.println("Vous avez choisi d'aller à l'inventaire");
                        instance.AfficherInventaire(heros, heros.inventory, menu);
                        break;

                    case 5 :
                        System.out.println("Vous avez choisi de quitter");
                        System.exit(0);
                        break;

                    case 4 :
                        System.out.println("Vous avez choisi de voir vos statistiques");
                        affichage.afficherStats(heros);
                        break;

                    case 1475963 :
                        System.out.println("Menu de debug");
                        System.out.println("1. Ajouter des niveaux");
                        System.out.println("2. Ajouter des points de vie");
                        System.out.println("3. Ajouter de la force");
                        System.out.println("4. Ajouter de l'agilité");
                        System.out.println("5. Ajouter de l'intelligence");
                        System.out.println("6. Afficher la map");

                        int choixDebug = sc.nextInt();
                        switch (choixDebug) {
                            case 1 :
                                System.out.println("Combien de niveaux voulez-vous ajouter ?");
                                int niveau = sc.nextInt();
                                heros.setNiveau(heros.getNiveau() + niveau);
                                break;

                            case 2 :
                                System.out.println("Combien de points de vie voulez-vous ajouter ?");
                                int vie = sc.nextInt();
                                heros.setVie(heros.getVie() + vie);
                                break;

                            case 3 :
                                System.out.println("Combien de force voulez-vous ajouter ?");
                                int force = sc.nextInt();
                                heros.setForce(heros.getForce() + force);
                                break;

                            case 4 :
                                System.out.println("Combien d'agilité voulez-vous ajouter ?");
                                int agilite = sc.nextInt();
                                heros.setAgilite(heros.getAgilite() + agilite);
                                break;

                            case 5 :
                                System.out.println("Combien d'intelligence voulez-vous ajouter ?");
                                int intelligence = sc.nextInt();
                                heros.setIntelligence(heros.getIntelligence() + intelligence);
                                break;
                            case 6 :
                                maps.afficherMap();
                                break;
                    }
                    default :System.out.println("Choix invalide");
                }
            }
        }


    }
}
