package Client.Menu.Affichage;

import Client.Joueur.Ami.Heros;

public class Affichage {

    // Constructeur

    public Affichage() {

    }

    // Affichage

    public void afficherMenu() {
        System.out.println("1. Créer un personnage");
        System.out.println("2. Charger un personnage");
        System.out.println("3. Quitter");
    }

    public void afficherStats(Heros heros) {
        System.out.println("Nom : " + heros.getNom());
        System.out.println("Niveau : " + heros.getNiveau());
        System.out.println("Expérience : " + heros.getexperience());
        System.out.println("Endurance : " + heros.getEndurance());
        System.out.println("Vie : " + heros.getVie());
        System.out.println("Force : " + heros.getForce());
        System.out.println("Agilité : " + heros.getAgilite());
        System.out.println("Intelligence : " + heros.getIntelligence());
        System.out.println("Arme : " + heros.weapon.getNomArme());
    }
}
