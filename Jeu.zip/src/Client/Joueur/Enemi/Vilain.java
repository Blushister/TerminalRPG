package Client.Joueur.Enemi;
import Client.Joueur.Ami.Heros;
import Client.Joueur.Joueur;

public class Vilain extends Joueur {
    int dmg;
    int def;
    private boolean vivant = true;

    public Vilain(String nom, int vie, int dmg, int def) {
        super(nom, vie, 100);
        this.dmg = dmg;
        this.def = def;
    }

    // Getters

    public String getNom() {
        return this.nom;
    }

    public int getVie() {
        return this.vie;
    }

    public int getDmg() {
        return this.dmg;
    }

    public int getDef() {
        return this.def;
    }

    public boolean getVivant() {
        return this.vivant;
    }

    // Setters

    public void setDmg(int dmg) {
        this.dmg = dmg;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public void setVivant(boolean vivant) {
        this.vivant = vivant;
    }

    public void attaquer(Heros heros) {
        heros.setVie(heros.getVie() - this.dmg);
    }

    public void mourrir(Heros heros) {
        this.vivant = false;
        heros.gainXp(this.experience);

    }
}
