package Client.Network;

import Client.Joueur.Ami.Heros;
import Client.Objets.Arme.Arme;

import java.io.FileInputStream;
import java.sql.*;
import java.util.Properties;

public class Manager {
    public static Connection Connector() throws Exception {

        Properties props = new Properties();
        try (FileInputStream in = new FileInputStream("conf.properties")) {
            props.load(in);
        }

        Class.forName(props.getProperty("jdbc.driver.class"));

        String url = props.getProperty("jdbc.url");
        String username = props.getProperty("jdbc.username");
        String password = props.getProperty("jdbc.password");

        Connection connection = DriverManager.getConnection(url, username, password);

        return connection;
    }

    // Sauvegarder les données du joueur dans la base de données

    public static void saveDataPlayer(Heros heros) throws Exception {
        Connection connection = Connector();

        String sql = "INSERT INTO player (nom, level, xp, hp, endurance, mp, p_force, inteligence, agilite, souls, PositionX, PositionY, Nom_arme) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, heros.name);
        statement.setInt(2, heros.lvl);
        statement.setInt(3, heros.xp);
        statement.setInt(4, heros.vie);
        statement.setInt(5, heros.endurance);
        statement.setInt(6, heros.mp);
        statement.setInt(7, heros.force);
        statement.setInt(8, heros.intelligence);
        statement.setInt(9, heros.agilite);
        statement.setInt(10, heros.souls);
        statement.setInt(11, heros.PositionX);
        statement.setInt(12, heros.PositionY);
        statement.setString(13, heros.weapon.getNomArme());


        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Donnée sauvegardée avec succès");
        }
    }

    // Update les données du joueur dans la base de données

    public static void updateDataPlayer(Heros heros) throws Exception {
        Connection connection = Connector();

        String sql = "UPDATE player SET nom = ?, level = ?, xp = ?, hp = ?, endurance = ?, mp = ?, p_force = ?, inteligence = ?, agilite = ?, souls = ?, PositionX = ?, PositionY = ?, Nom_arme = ?";

        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, heros.name);
        statement.setInt(2, heros.lvl);
        statement.setInt(3, heros.xp);
        statement.setInt(4, heros.vie);
        statement.setInt(5, heros.endurance);
        statement.setInt(6, heros.mp);
        statement.setInt(7, heros.force);
        statement.setInt(8, heros.intelligence);
        statement.setInt(9, heros.agilite);
        statement.setInt(10, heros.souls);
        statement.setInt(11, heros.PositionX);
        statement.setInt(12, heros.PositionY);
        statement.setString(13, heros.weapon.getNomArme());

        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Donnée mise à jour avec succès");
        }
    }

    // Récupérer les données du joueur dans la base de données

    public static void getDataPlayer(Heros heros) throws Exception {
        Connection connection = Connector();

        String sql = "SELECT * FROM player WHERE nom = ?";

        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, heros.name);

        ResultSet result = statement.executeQuery();

        while (result.next()){
            heros.name = result.getString("nom");
            heros.lvl = result.getInt("level");
            heros.xp = result.getInt("xp");
            heros.vie = result.getInt("hp");
            heros.endurance = result.getInt("endurance");
            heros.mp = result.getInt("mp");
            heros.force = result.getInt("p_force");
            heros.intelligence = result.getInt("inteligence");
            heros.agilite = result.getInt("agilite");
            heros.souls = result.getInt("souls");
            heros.PositionX = result.getInt("PositionX");
            heros.PositionY = result.getInt("PositionY");

        }
    }

    // Faire la meme chose mais pour les armes

    public static void saveDataArme(Arme arme) throws Exception {
        Connection connection = Connector();

        String sql = "INSERT INTO weapon (Nom_arme, degats, poids, valeur) VALUES (?, ?, ?, ?)";

        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, arme.getNomArme());
        statement.setInt(2, arme.getDegats());
        statement.setInt(3, arme.getPoids());
        statement.setInt(4, arme.getValeur());

        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Donnée sauvegardée avec succès");
        }
    }
}