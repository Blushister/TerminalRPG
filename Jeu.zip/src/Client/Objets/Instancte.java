package Client.Objets;

import Client.Joueur.Ami.Heros;
import Client.Joueur.Enemi.Vilain;
import Client.Maps.Maps;
import Client.Menu.Menu;
import Client.Network.Manager;
import Client.Objets.Arme.Arme;
import Client.Objets.Consommable.Consommable;

import java.util.ArrayList;
import java.util.Scanner;

public class Instancte {


    // Constructeur

    public Instancte() {

    }

    // Méthodes


    // Methode de l'inventaire
    public void InventaireStart (ArrayList<Objects> inventaire) {
Consommable potion_de_vie = new Consommable("Potion de vie", 1, 10, 1, 1, 1, 1,1,1);
        inventaire.add(potion_de_vie);
        Consommable potion_de_force = new Consommable("Potion de force", 1, 10, 1, 1, 1, 1,1,1);
        inventaire.add(potion_de_force);
        inventaire.add(potion_de_force);
        inventaire.add(potion_de_force);
        Consommable potion_de_vitesse = new Consommable("Potion de vitesse", 1, 10, 1, 1, 1, 1,1,1);
        inventaire.add(potion_de_vitesse);
        Consommable potion_de_magie = new Consommable("Potion de magie", 1, 10, 1, 1, 1, 1,1,1);
        inventaire.add(potion_de_magie);
    }

    public void AfficherInventaire (Heros heros, ArrayList<Objects> inventaire, Menu menu) {
        this.verifierInventaire(inventaire);
        for (int i = 0; i < inventaire.size(); i++) {
            System.out.println(inventaire.get(i).getNoms() + " x" + inventaire.get(i).getQuantite());
        }

        menu.menuInventory();
        Scanner sc = new Scanner(System.in);
        int choix = sc.nextInt();
        switch (choix) {
            case 1:
                System.out.println("Vous avez choisi de consommer une potion");
                this.afficherConsommable(heros, inventaire);
                break;
            case 2:
                System.out.println("Vous avez choisi de Equiper / Desequiper une arme");
                this.afficherArme(inventaire);
                break;
            case 3:
                System.out.println("Vous avez choisi de Equiper / Desequiper une armure");
                break;
        }
    }

    // Afficher que les Objets Consommables contenus dans l'inventaire avec getClass().getSimpleName())

    public ArrayList<Consommable> afficherConsommable(Heros heros, ArrayList<Objects> inventaire) {
        ArrayList<Consommable> consommable = new ArrayList<>();
        this.verifierInventaire(inventaire);
        for (int i = 0; i < inventaire.size(); i++) {
            if (inventaire.get(i).getClass().getSimpleName().equals("Consommable")) {
                consommable.add((Consommable) inventaire.get(i));
            }
        }
        // Afficher les consommables
        for (int i = 0; i < consommable.size(); i++) {
            System.out.println(i + 1 + " : " + consommable.get(i).getNoms() + " x" + consommable.get(i).getQuantite());
        }

        // Choisir un consommable

        System.out.println("Choisissez un consommable");
        Scanner sc = new Scanner(System.in);
        int choix = sc.nextInt();
        switch (choix) {
            case 1:
                System.out.println("Vous avez choisi de consommer une potion de vie");
                this.boirePotionSoin(heros, consommable);
                break;
            case 2:
                System.out.println("Vous avez choisi de consommer une potion de force");
                break;
            case 3:
                System.out.println("Vous avez choisi de consommer une potion de vitesse");
                break;
            case 4:
                System.out.println("Vous avez choisi de consommer une potion de magie");
                break;
        }
        return consommable;
    }

    public void afficherArme(ArrayList<Objects> inventaire) {
        ArrayList<Arme> arme = new ArrayList<>();
        this.verifierInventaire(inventaire);
        for (int i = 0; i < inventaire.size(); i++) {
            if (inventaire.get(i).getClass().getSimpleName().equals("Arme")) {
                arme.add((Arme) inventaire.get(i));
            }
        }
        // Afficher les Armes
        for (int i = 0; i < arme.size(); i++) {
            System.out.println(i + " : " + arme.get(i).getNoms() + " x" + arme.get(i).getQuantite());
        }
    }

    public void verifierInventaire (ArrayList<Objects> inventaire) {
        for (int i = 0; i < inventaire.size(); i++) {
            for (int j = i + 1; j < inventaire.size(); j++) {
                if (inventaire.get(i).getNoms().equals(inventaire.get(j).getNoms())) {
                    inventaire.get(i).setQuantite(inventaire.get(i).getQuantite() + 1);
                    inventaire.remove(j);
                    j--;
                }
            }
        }
    }

    public ArrayList<Consommable> boirePotionSoin(Heros heros, ArrayList<Consommable> consommables) {
        for (int i = 0; i < consommables.size(); i++) {
            if (consommables.get(i).getQuantite() == 0) {
                System.out.println("Vous n'avez plus de potion de soin");
                break;
            }
            if (consommables.get(i).getNoms().equals("Potion de vie")) {
                consommables.get(i).setQuantite(consommables.get(i).getQuantite() - 1);
                heros.setVie(heros.getVie() + 50);
                System.out.println("Vous avez bu une potion de soins");
            }
        }


        return consommables;
    }

    // Instance des menus

    public void MenuInventaire (Heros heros, ArrayList<Objects> inventaire, Menu menu) {
        System.out.println("Inventaire");
        this.AfficherInventaire(heros, inventaire, menu);
    }

    // Instance
    public void InstanceCombat(Heros heros, Vilain vilain) {
        System.out.println("Vous avez rencontré un " + vilain.getNom() + " !");
        while (heros.getVie() > 0 && vilain.getVivant()) {
            System.out.println("Que voulez-vous faire ?");
            System.out.println("1. Attaquer");
            System.out.println("2. Utiliser un objet");
            System.out.println("3. Quitter");
            int choix = 0;
            Scanner sc = new Scanner(System.in);
            choix = sc.nextInt();
            switch (choix) {
                case 1:
                    System.out.println("Vous attaquez le " + vilain.getNom() + " !");
                    vilain.setVie((int) (vilain.getVie() - (heros.weapon.getDegats() + heros.getForce() * 0.5)));
                    if (vilain.getVie() <= 0) {
                        System.out.println("L'ennemi est mort !");
                    } else {
                        System.out.println("Il lui reste " + vilain.getVie() + " points de vie.");
                    }
                    if (vilain.getVie() <= 0) {
                        System.out.println("Vous avez tué le " + vilain.getNom() + " !");
                        vilain.mourrir(heros);
                        break;
                    } else if (vilain.getVivant()) {
                        System.out.println("Le " + vilain.getNom() + " vous attaque !");
                        heros.setVie(heros.getVie() - vilain.getDmg());
                        System.out.println("Il vous reste " + heros.getVie() + " points de vie.");
                        break;
                    } else if (heros.getVie() <= 0) {
                        System.out.println("Vous avez été tué par le " + vilain.getNom() + " !");
                        break;
                    }
                    break;
                case 2:
                    System.out.println("Boire une potion de soin ?");
                    System.out.println("1. Oui");
                    System.out.println("2. Non");
                    int choix2 = 0;
                    Scanner sc2 = new Scanner(System.in);
                    choix2 = sc2.nextInt();
                    switch (choix2) {
                        case 1:
                            this.boirePotionSoin(heros, this.boirePotionSoin(heros, afficherConsommable(heros, heros.inventory)));
                            break;
                        case 2:
                            break;
                    }
                case 3:
                    System.out.println("Vous fuyez le combat.");
                    return;

            }
        }
    }

    public void eventMap(String maps[][], Heros heros, Vilain vilain) {
        System.out.println("Vous êtes sur la map " + heros.getPositionY() + " " + heros.getPositionX());
        System.out.println(maps[heros.getPositionY()][heros.getPositionX()]);
        if (maps[heros.getPositionY()][heros.getPositionX()] == "❎") {
            System.out.println("Vous êtes a un village");
            heros.setVillage(true);
        } else {
            heros.setVillage(false);
            vilain.setVivant(true);
            vilain.setVie(100);
        }
    }


    // Slot Equipement

    public void equiperArme(Heros heros, Arme arme) {
        heros.setWeapon(arme);
        heros.setForce(heros.getForce() + arme.getDegats());
    }

    public void ResumeSave(Heros heros, Maps map) throws Exception {
        Manager.getDataPlayer(heros);
        map.setHerosPosition(heros, heros.getPositionY(), heros.getPositionX());
    }

    public void Save(Heros heros, Arme arme) throws Exception {
        Manager.saveDataArme(arme);
        Manager.saveDataPlayer(heros);
    }
}
